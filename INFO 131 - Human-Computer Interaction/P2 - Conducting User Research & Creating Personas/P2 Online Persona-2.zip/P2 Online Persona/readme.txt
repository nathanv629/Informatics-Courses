--Readme document for *Erick Burciaga*--

interactive online Persona for INF131 P2 assignment